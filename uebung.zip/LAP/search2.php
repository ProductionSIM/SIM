<?php
include('header.php');
include('nav.php');?>
<!-- https://www.cloudways.com/blog/live-search-php-mysql-ajax/ -->


<input class="ms-5" type="text" id="search" placeholder="Search" />

<div id="display"></div>







<?php include('footer.php'); ?>





